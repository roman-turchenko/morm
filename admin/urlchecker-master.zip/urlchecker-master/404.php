<?
	header($_SERVER['SERVER_PROTOCOL'] . " 404 Not Found");
?>
<h3>Страница не найдена.</h3>
