<?php
/**
 * Created by PhpStorm.
 * User: roman.turchenko
 * Date: 26.06.14
 * Time: 16:34
 */

/**
 * System constants
 */
define('CORE_DIR', realpath(dirname(__FILE__)));
define('CONTEROLLERS_DIR', CORE_DIR.'/controllers');
define('VIEWS_DIR', CORE_DIR.'/views');
define('MODELS_DIR', CORE_DIR.'/models');
define('LIBS_DIR', CORE_DIR.'/libs');


/**
 * User constants
 */