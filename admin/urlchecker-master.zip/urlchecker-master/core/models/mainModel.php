<?
class mainModel extends classModel{

	function __construct(){ }
}
?>