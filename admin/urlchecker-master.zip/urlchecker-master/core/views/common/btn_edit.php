<?php
/**
 * Created by PhpStorm.
 * User: roman.turchenko
 * Date: 04.08.14
 * Time: 16:54
 */
?>

<a href="<?=$params['url']?>" class="edit_btn" title="Edit this">A</a>