<?php
/**
 * Created by PhpStorm.
 * User: roman.turchenko
 * Date: 25.07.14
 * Time: 12:34
 */
?>
<div class="filter_section"><?=$params['data']?></div>