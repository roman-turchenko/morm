<?php
/**
 * Created by PhpStorm.
 * User: roman.turchenko
 * Date: 04.08.14
 * Time: 17:31
 */
?>
<a href="<?=$params['url']?>">Add</a>