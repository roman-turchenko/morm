    <div class="clear"></div>
    </div> <!-- wrapper div close tag -->
</body>
</html>