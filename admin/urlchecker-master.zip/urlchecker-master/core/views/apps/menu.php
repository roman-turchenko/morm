<?php
/**
 * Created by PhpStorm.
 * User: roman.turchenko
 * Date: 08.07.14
 * Time: 16:54
 */
?>
<ul>
    <li><u id="addApp">Add</u></li>
    <li><a href="/?controller=auth&action=logout">Logout</a></li>
</ul>