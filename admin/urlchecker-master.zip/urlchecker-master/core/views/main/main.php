<?
	include(VIEWS_DIR.'/common/header.php');
?>
	Hello Word!
<?
	include(VIEWS_DIR.'/common/footer.php');
?>


